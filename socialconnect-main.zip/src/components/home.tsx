import React, { useState } from "react";
import Header from "./layout/Header";
import CreatePost from "./feed/CreatePost";
import PostList from "./feed/PostList";
import FriendsSidebar from "./sidebar/FriendsSidebar";
import LeftSidebar from "./sidebar/LeftSidebar";
import { useAuth } from "@/lib/auth";

const Home = () => {
  const { user } = useAuth();
  const [refreshKey, setRefreshKey] = useState(0);

  const handlePostCreated = () => {
    setRefreshKey((prev) => prev + 1);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header
        userAvatar={`https://api.dicebear.com/7.x/avataaars/svg?seed=${user?.id}`}
      />

      <main className="pt-[80px] pb-8 px-4 max-w-[1512px] mx-auto">
        <div className="flex gap-6 relative">
          {/* Left Sidebar - hidden on mobile */}
          <div className="hidden md:block w-[320px] flex-shrink-0">
            <LeftSidebar />
          </div>

          {/* Main content area - full width on mobile */}
          <div className="flex-1 max-w-[680px] w-full mx-auto">
            <div className="space-y-4">
              <CreatePost
                userAvatar={`https://api.dicebear.com/7.x/avataaars/svg?seed=${user?.id}`}
                userName={user?.email}
                onPost={handlePostCreated}
              />
              <PostList key={refreshKey} />
            </div>
          </div>

          {/* Right sidebar - hidden on mobile */}
          <div className="hidden lg:block w-[320px]">
            <FriendsSidebar />
          </div>
        </div>
      </main>
    </div>
  );
};

export default Home;
