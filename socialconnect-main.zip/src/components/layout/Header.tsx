import React from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Avatar } from "@/components/ui/avatar";
import {
  Bell,
  MessageCircle,
  Search,
  Menu,
  Home,
  Users,
  Video,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface HeaderProps {
  userAvatar?: string;
  unreadNotifications?: number;
  unreadMessages?: number;
}

const Header = ({
  userAvatar = "https://api.dicebear.com/7.x/avataaars/svg?seed=default",
  unreadNotifications = 3,
  unreadMessages = 2,
}: HeaderProps) => {
  return (
    <header className="w-full h-16 bg-background border-b fixed top-0 left-0 z-50">
      <div className="max-w-[1512px] mx-auto h-full px-4 flex items-center justify-between">
        {/* Left section */}
        <div className="flex items-center gap-2">
          <h1 className="text-[#1877F2] text-2xl font-bold mr-4">social</h1>
          <div className="relative max-w-[320px] hidden sm:block">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input
              type="search"
              placeholder="Search..."
              className="pl-10 w-full"
            />
          </div>
        </div>

        {/* Center section - Navigation */}
        <nav className="flex items-center gap-1">
          <Button variant="ghost" size="lg" className="hidden md:flex">
            <Home className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="lg" className="hidden md:flex">
            <Users className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="lg" className="hidden md:flex">
            <Video className="h-5 w-5" />
          </Button>
        </nav>

        {/* Right section */}
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" className="relative">
            <Bell className="h-5 w-5" />
            {unreadNotifications > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
                {unreadNotifications}
              </span>
            )}
          </Button>

          <Button variant="ghost" size="icon" className="relative">
            <MessageCircle className="h-5 w-5" />
            {unreadMessages > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
                {unreadMessages}
              </span>
            )}
          </Button>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="rounded-full">
                <Avatar className="h-8 w-8">
                  <img
                    src={userAvatar}
                    alt="User avatar"
                    className="object-cover"
                  />
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>Profile</DropdownMenuItem>
              <DropdownMenuItem>Settings</DropdownMenuItem>
              <DropdownMenuItem>Sign out</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <Button variant="ghost" size="icon" className="md:hidden">
            <Menu className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </header>
  );
};

export default Header;
