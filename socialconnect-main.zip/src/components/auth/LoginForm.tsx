import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { useAuth } from "@/lib/auth";
import { useToast } from "@/components/ui/use-toast";

const LoginForm = () => {
  const navigate = useNavigate();
  const { signIn, signUp } = useAuth();
  const { toast } = useToast();

  const [isLoading, setIsLoading] = useState(false);
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      let error;
      if (isSignUp) {
        ({ error } = await signUp(email, password, fullName));
      } else {
        ({ error } = await signIn(email, password));
      }

      if (error) throw error;

      navigate("/home");
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Lỗi",
        description: error.message,
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 p-4">
      <Card className="w-full max-w-md p-8 bg-white">
        <h1 className="text-[#1877F2] text-4xl font-bold text-center mb-8">
          social
        </h1>

        <form onSubmit={handleSubmit} className="space-y-4">
          {isSignUp && (
            <div className="space-y-2">
              <Input
                placeholder="Họ và tên"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                required
              />
            </div>
          )}

          <div className="space-y-2">
            <Input
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Input
              type="password"
              placeholder="Mật khẩu"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          <Button
            type="submit"
            className="w-full bg-[#1877F2] hover:bg-[#1877F2]/90"
            disabled={isLoading}
          >
            {isLoading ? "Đang xử lý..." : isSignUp ? "Đăng ký" : "Đăng nhập"}
          </Button>
        </form>

        {!isSignUp && (
          <div className="mt-4 text-center">
            <a href="#" className="text-[#1877F2] text-sm hover:underline">
              Quên mật khẩu?
            </a>
          </div>
        )}

        <hr className="my-6" />

        <div className="text-center">
          <Button
            type="button"
            variant="secondary"
            className="bg-[#42B72A] hover:bg-[#42B72A]/90 text-white"
            onClick={() => setIsSignUp(!isSignUp)}
          >
            {isSignUp ? "Đã có tài khoản? Đăng nhập" : "Tạo tài khoản mới"}
          </Button>
        </div>
      </Card>
    </div>
  );
};

export default LoginForm;
