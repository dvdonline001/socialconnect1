import { useNavigate } from "react-router-dom";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Avatar } from "@/components/ui/avatar";
import { useTheme } from "@/lib/theme-provider";
import {
  LogOut,
  Moon,
  Sun,
  User,
  Users,
  Clock,
  Bookmark,
  Users2,
  Video,
  Store,
  LayoutGrid,
} from "lucide-react";

const LeftSidebar = () => {
  const navigate = useNavigate();
  const { signOut, user } = useAuth();
  const { theme, setTheme } = useTheme();

  const handleSignOut = async () => {
    await signOut();
    navigate("/login");
  };

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };

  return (
    <div className="w-[320px] h-[calc(100vh-64px)] fixed left-0 top-[64px] bg-background border-r overflow-y-auto p-4">
      <div className="space-y-2">
        {/* Profile */}
        <Button
          variant="ghost"
          className="w-full justify-start text-base font-medium"
          size="lg"
        >
          <Avatar className="h-8 w-8 mr-3">
            <img
              src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${user?.id}`}
              alt="avatar"
            />
          </Avatar>
          {user?.email}
        </Button>

        {/* Menu Items */}
        <Button
          variant="ghost"
          className="w-full justify-start text-base font-medium"
          size="lg"
        >
          <Users className="mr-3 h-5 w-5" />
          Bạn bè
        </Button>

        <Button
          variant="ghost"
          className="w-full justify-start text-base font-medium"
          size="lg"
        >
          <Clock className="mr-3 h-5 w-5" />
          Kỷ niệm
        </Button>

        <Button
          variant="ghost"
          className="w-full justify-start text-base font-medium"
          size="lg"
        >
          <Bookmark className="mr-3 h-5 w-5" />
          Đã lưu
        </Button>

        <Button
          variant="ghost"
          className="w-full justify-start text-base font-medium"
          size="lg"
        >
          <Users2 className="mr-3 h-5 w-5" />
          Nhóm
        </Button>

        <Button
          variant="ghost"
          className="w-full justify-start text-base font-medium"
          size="lg"
        >
          <Video className="mr-3 h-5 w-5" />
          Video
        </Button>

        <Button
          variant="ghost"
          className="w-full justify-start text-base font-medium"
          size="lg"
        >
          <Store className="mr-3 h-5 w-5" />
          Marketplace
        </Button>

        <Button
          variant="ghost"
          className="w-full justify-start text-base font-medium"
          size="lg"
        >
          <LayoutGrid className="mr-3 h-5 w-5" />
          Bảng feed
        </Button>

        {/* Theme Toggle */}
        <Button
          variant="ghost"
          className="w-full justify-start text-base font-medium"
          size="lg"
          onClick={toggleTheme}
        >
          {theme === "dark" ? (
            <>
              <Sun className="mr-3 h-5 w-5" />
              Chế độ sáng
            </>
          ) : (
            <>
              <Moon className="mr-3 h-5 w-5" />
              Chế độ tối
            </>
          )}
        </Button>

        {/* Sign Out */}
        <Button
          variant="ghost"
          className="w-full justify-start text-base font-medium text-red-500 hover:text-red-600 hover:bg-red-50"
          size="lg"
          onClick={handleSignOut}
        >
          <LogOut className="mr-3 h-5 w-5" />
          Đăng xuất
        </Button>
      </div>
    </div>
  );
};

export default LeftSidebar;
