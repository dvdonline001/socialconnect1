import React from "react";
import { Card } from "@/components/ui/card";
import { Avatar } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";

interface Friend {
  id: string;
  name: string;
  avatar: string;
  isOnline: boolean;
  lastSeen?: string;
}

interface FriendsSidebarProps {
  friends?: Friend[];
}

const FriendsSidebar = ({
  friends = [
    {
      id: "1",
      name: "Alice Johnson",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Alice",
      isOnline: true,
    },
    {
      id: "2",
      name: "Bob Smith",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Bob",
      isOnline: false,
      lastSeen: "5m ago",
    },
    {
      id: "3",
      name: "Carol White",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Carol",
      isOnline: true,
    },
    {
      id: "4",
      name: "David Brown",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=David",
      isOnline: false,
      lastSeen: "1h ago",
    },
    {
      id: "5",
      name: "Eve Anderson",
      avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=Eve",
      isOnline: true,
    },
  ],
}: FriendsSidebarProps) => {
  return (
    <Card className="w-[320px] h-[918px] bg-background p-4 fixed right-0 top-[64px]">
      <div className="flex flex-col h-full">
        <h2 className="text-lg font-semibold mb-4">Friends</h2>

        <div className="mb-4">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium">Online</span>
            <Badge
              variant="secondary"
              className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100"
            >
              {friends.filter((f) => f.isOnline).length}
            </Badge>
          </div>
        </div>

        <ScrollArea className="flex-1">
          <div className="space-y-2">
            {friends.map((friend) => (
              <div
                key={friend.id}
                className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted cursor-pointer"
              >
                <div className="relative">
                  <Avatar className="h-10 w-10">
                    <img
                      src={friend.avatar}
                      alt={friend.name}
                      className="object-cover"
                    />
                  </Avatar>
                  {friend.isOnline && (
                    <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-background" />
                  )}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium">{friend.name}</p>
                  {!friend.isOnline && friend.lastSeen && (
                    <p className="text-xs text-muted-foreground">
                      {friend.lastSeen}
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </div>
    </Card>
  );
};

export default FriendsSidebar;
