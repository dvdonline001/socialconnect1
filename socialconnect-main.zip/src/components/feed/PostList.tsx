import { useEffect, useState } from "react";
import PostCard from "./PostCard";
import { ScrollArea } from "@/components/ui/scroll-area";
import { supabase } from "@/lib/supabase";

interface Post {
  id: string;
  user_id: string;
  content: string;
  image_url?: string;
  video_url?: string;
  created_at: string;
}

const PostList = () => {
  const [posts, setPosts] = useState<Post[]>([]);

  // Fetch posts function
  const fetchPosts = async () => {
    try {
      const { data, error } = await supabase
        .from("posts")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) {
        console.error("Error fetching posts:", error);
        return;
      }

      console.log("Fetched posts:", data);
      setPosts(data || []);
    } catch (error) {
      console.error("Error:", error);
    }
  };

  // Initial fetch
  useEffect(() => {
    fetchPosts();
  }, []);

  // Subscribe to changes
  useEffect(() => {
    const postsSubscription = supabase
      .channel("schema-db-changes")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "posts",
        },
        () => {
          console.log("Database change detected, fetching posts...");
          fetchPosts();
        },
      )
      .subscribe();

    return () => {
      postsSubscription.unsubscribe();
    };
  }, []);

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now.getTime() - date.getTime();

    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (days > 0) return `${days} ngày trước`;
    if (hours > 0) return `${hours} giờ trước`;
    if (minutes > 0) return `${minutes} phút trước`;
    return "Vừa xong";
  };

  return (
    <div className="w-full max-w-[680px] mx-auto bg-background min-h-screen">
      <ScrollArea className="h-[800px] px-4">
        {posts.length === 0 ? (
          <div className="text-center text-muted-foreground py-8">
            Chưa có bài viết nào
          </div>
        ) : (
          posts.map((post) => (
            <PostCard
              key={post.id}
              userAvatar={`https://api.dicebear.com/7.x/avataaars/svg?seed=${post.user_id}`}
              userName={post.user_id}
              timestamp={formatTimestamp(post.created_at)}
              content={post.content}
              imageUrl={post.image_url}
              videoUrl={post.video_url}
              likes={0}
              comments={0}
              shares={0}
            />
          ))
        )}
      </ScrollArea>
    </div>
  );
};

export default PostList;
