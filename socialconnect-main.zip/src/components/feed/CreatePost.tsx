import { useState, useRef } from "react";
import { Card } from "@/components/ui/card";
import { Avatar } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { ImageIcon, SmileIcon, VideoIcon, X } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";
import { supabase } from "@/lib/supabase";
import { uploadFile } from "@/lib/upload";
import { useAuth } from "@/lib/auth";

interface CreatePostProps {
  userAvatar?: string;
  userName?: string;
  onPost?: () => void;
}

const CreatePost = ({
  userAvatar = "https://api.dicebear.com/7.x/avataaars/svg?seed=creator",
  userName = "John Doe",
  onPost = () => {},
}: CreatePostProps) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [content, setContent] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [mediaFile, setMediaFile] = useState<File | null>(null);
  const [mediaPreview, setMediaPreview] = useState<string>("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Kiểm tra kích thước file (giới hạn 10MB)
      if (file.size > 10 * 1024 * 1024) {
        toast({
          variant: "destructive",
          title: "Lỗi",
          description: "File không được vượt quá 10MB",
        });
        return;
      }

      // Kiểm tra loại file
      const fileType = file.type;
      if (!fileType.startsWith("image/") && !fileType.startsWith("video/")) {
        toast({
          variant: "destructive",
          title: "Lỗi",
          description: "Chỉ chấp nhận file ảnh hoặc video",
        });
        return;
      }

      setMediaFile(file);
      const previewUrl = URL.createObjectURL(file);
      setMediaPreview(previewUrl);
    }
  };

  const handlePost = async () => {
    if (!content.trim() && !mediaFile) {
      toast({
        variant: "destructive",
        title: "Lỗi",
        description: "Vui lòng nhập nội dung hoặc thêm media",
      });
      return;
    }

    setIsLoading(true);

    try {
      let mediaUrl = "";
      if (mediaFile) {
        const bucket = mediaFile.type.startsWith("image/")
          ? "images"
          : "videos";
        mediaUrl = await uploadFile(mediaFile, bucket);
      }

      const { error } = await supabase.from("posts").insert({
        user_id: user?.id,
        content: content.trim(),
        image_url: mediaFile?.type.startsWith("image/") ? mediaUrl : null,
        video_url: mediaFile?.type.startsWith("video/") ? mediaUrl : null,
      });

      if (error) throw error;

      toast({
        title: "Thành công",
        description: "Đã đăng bài viết",
      });

      // Reset form
      setContent("");
      setMediaFile(null);
      setMediaPreview("");
      onPost();
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Lỗi",
        description: "Không thể đăng bài viết",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-[680px] bg-background p-4">
      <div className="flex items-start gap-3">
        <Avatar className="h-10 w-10">
          <img src={userAvatar} alt={userName} className="object-cover" />
        </Avatar>

        <div className="flex-1">
          <Textarea
            placeholder="Bạn đang nghĩ gì?"
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="min-h-[100px] resize-none border-none focus-visible:ring-0 text-sm bg-background"
          />

          {mediaPreview && (
            <div className="relative mt-2 rounded-lg overflow-hidden">
              {mediaFile?.type.startsWith("image/") ? (
                <img
                  src={mediaPreview}
                  alt="Preview"
                  className="max-h-[300px] w-full object-cover rounded-lg"
                />
              ) : (
                <video
                  src={mediaPreview}
                  controls
                  className="max-h-[300px] w-full rounded-lg"
                />
              )}
              <Button
                variant="destructive"
                size="icon"
                className="absolute top-2 right-2"
                onClick={() => {
                  setMediaFile(null);
                  setMediaPreview("");
                }}
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          )}

          <input
            type="file"
            ref={fileInputRef}
            className="hidden"
            accept="image/*,video/*"
            onChange={handleFileSelect}
          />

          <div className="mt-4 flex items-center justify-between border-t pt-4">
            <div className="flex gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => fileInputRef.current?.click()}
              >
                <ImageIcon className="h-5 w-5 mr-2" />
                Ảnh/Video
              </Button>
            </div>

            <Button
              variant="default"
              size="sm"
              className="bg-[#1877F2] hover:bg-[#1877F2]/90"
              onClick={handlePost}
              disabled={isLoading}
            >
              {isLoading ? "Đang đăng..." : "Đăng"}
            </Button>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default CreatePost;
