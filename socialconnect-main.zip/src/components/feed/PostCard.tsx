import React from "react";
import { Card } from "@/components/ui/card";
import { Avatar } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Heart, MessageCircle, Share2, MoreHorizontal } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface PostCardProps {
  userAvatar?: string;
  userName?: string;
  timestamp?: string;
  content?: string;
  imageUrl?: string;
  videoUrl?: string;
  likes?: number;
  comments?: number;
  shares?: number;
}

const PostCard = ({
  userAvatar = "https://api.dicebear.com/7.x/avataaars/svg?seed=default",
  userName = "John Doe",
  timestamp = "2 hours ago",
  content = "This is a sample post content. It could be much longer and contain multiple paragraphs of text.",
  imageUrl,
  videoUrl,
  likes = 42,
  comments = 12,
  shares = 3,
}: PostCardProps) => {
  return (
    <Card className="w-full max-w-[680px] bg-background mb-4 overflow-hidden">
      <div className="p-4">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Avatar className="h-10 w-10">
              <img src={userAvatar} alt={userName} className="object-cover" />
            </Avatar>
            <div>
              <h3 className="font-semibold text-sm">{userName}</h3>
              <p className="text-xs text-muted-foreground">{timestamp}</p>
            </div>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon">
                <MoreHorizontal className="h-5 w-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              <DropdownMenuItem>Save Post</DropdownMenuItem>
              <DropdownMenuItem>Report</DropdownMenuItem>
              <DropdownMenuItem>Hide Post</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Content */}
        <div className="mt-3">
          <p className="text-sm">{content}</p>
        </div>

        {/* Media */}
        {imageUrl && (
          <div className="mt-3 -mx-4">
            <img
              src={imageUrl}
              alt="Post content"
              className="w-full h-[300px] object-cover"
            />
          </div>
        )}

        {videoUrl && (
          <div className="mt-3 -mx-4">
            <video
              src={videoUrl}
              controls
              className="w-full h-[300px] object-contain bg-black"
            />
          </div>
        )}

        {/* Engagement Stats */}
        <div className="mt-3 flex items-center text-sm text-muted-foreground">
          <span>{likes} likes</span>
          <span className="mx-2">•</span>
          <span>{comments} comments</span>
          <span className="mx-2">•</span>
          <span>{shares} shares</span>
        </div>

        {/* Action Buttons */}
        <div className="mt-3 flex items-center justify-between pt-3 border-t border-border">
          <Button variant="ghost" className="flex-1">
            <Heart className="h-5 w-5 mr-2" />
            Like
          </Button>
          <Button variant="ghost" className="flex-1">
            <MessageCircle className="h-5 w-5 mr-2" />
            Comment
          </Button>
          <Button variant="ghost" className="flex-1">
            <Share2 className="h-5 w-5 mr-2" />
            Share
          </Button>
        </div>
      </div>
    </Card>
  );
};

export default PostCard;
