import { supabase } from "./supabase";

export async function uploadFile(file: File, bucket: string) {
  try {
    // Tạo tên file ngẫu nhiên với timestamp để tránh trùng
    const fileExt = file.name.split(".").pop();
    const fileName = `${Date.now()}-${Math.random()}.${fileExt}`;

    // Upload file
    const { error: uploadError, data } = await supabase.storage
      .from(bucket)
      .upload(fileName, file, {
        cacheControl: "3600",
        upsert: false,
      });

    if (uploadError) {
      console.error("Upload error:", uploadError);
      throw new Error("Không thể upload file. Vui lòng thử lại.");
    }

    if (!data) {
      throw new Error("Không nhận được thông tin file sau khi upload.");
    }

    // Lấy public URL
    const { data: urlData } = supabase.storage
      .from(bucket)
      .getPublicUrl(data.path);

    if (!urlData?.publicUrl) {
      throw new Error("Không thể lấy đường dẫn file.");
    }

    return urlData.publicUrl;
  } catch (error) {
    console.error("Error in uploadFile:", error);
    throw error;
  }
}
